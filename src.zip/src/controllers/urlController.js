const urlModel = require("../models/urlModel")
const validUrl = require('valid-url')
const shortid = require('short-id')

// THIS IS BASE URL-----
const baseUrl = 'http:localhost:3000'

const shortUrl = async function (req, res) {
    try {
        // DESTRUCTURING DATA FETCH BY REQ.BODY----
        const { longUrl } = req.body

        // CHECK VALIDATION OF GIVEN LONG URL-----
        if (!validUrl.isUri(longUrl)) {
            return res.status(400).send({ status: false, message: "Invalid Long URL" })
        }

        // CHECK VALIDATION OF GIVEN BASE URL-----
        if (!validUrl.isUri(baseUrl)) {
            return res.status(400).send({ status: false, message: "Invalid Base URL" })
        }

        // GENERATE URLCODE------
        const urlCode = shortid.generate()
        console.log(urlCode)
        
        // FIND DOCUMENT CONTAINING SAME URLCODE i.e DUDUPLICATE URLCODE-----
        const findUrlCode = await urlModel.findOne({urlCode:urlCode})

        if(findUrlCode){
            return res.status(400).send({ status: false, message: "UrlCode alrady present" })
        }

        // FIND LONG URL ALRADY PRESENT OR NOT IN DB----
        let url = await urlModel.findOne({ longUrl })

        if (url) {
            return res.status(400).send({ status: false, message: "URL alrady shorted" })
        }

        // CREATE SHORT URL----
        const shortUrl = baseUrl + '/' + urlCode
        console.log(shortUrl)

        // FIND DOCUMENT HAVING SAME SHORTURL i.e DUDUPLICATE SHORTURL-----
        const findShortUrl = await urlModel.findOne({shortUrl:shortUrl})

        if(findShortUrl){
            return res.status(400).send({ status: false, message: "Short-Url alrady present" })
        }

        // MAKE OBJECT CONTAINING ALL MANDATORY FIELDS-----
        let createUrl = {
            longUrl: longUrl,
            shortUrl: shortUrl,
            urlCode: urlCode
        }
        // CREATE DOCUMENT IN DB------
        let createdata = await urlModel.create(createUrl)
        res.status(201).send({ status: true, data: createdata })
    }
    catch (err) {
        return res.status(500).send({ status: false, Error: err.message })
    }
}

// REDIRECTING TO THE LONG URL----
const redirectUrl = async function (req, res) {
    try {
        //FETCH URLCODE FROM PARAMS----
        let shortId = req.params.urlCode

        // FINDING IN DATABASE----
        let originalUrlDetails = await urlModel.findOne({ urlCode: shortId })
        console.log(originalUrlDetails)

        if (originalUrlDetails) {
            return res.status(302).redirect(originalUrlDetails.longUrl)
        } else {
            return res.status(404).send({status: false, msg: "No URL Found"})
        }
    }
    catch (err) {
        return res.status(500).send({ status: false, Error: err.message })
    }
}

// EXPORT MODULE AND MAKE IT PUBLIC-----
module.exports.shortUrl = shortUrl
module.exports.redirectUrl = redirectUrl